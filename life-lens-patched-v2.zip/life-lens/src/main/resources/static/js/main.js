// Life Lens - Main JavaScript

// Sidebar collapse state
const sidebarEl = document.getElementById('sidebar');
const mainWrapper = document.querySelector('.main-wrapper');

// Restore sidebar state
if (localStorage.getItem('sidebarCollapsed') === 'true') {
    sidebarEl?.classList.add('collapsed');
    mainWrapper?.classList.add('expanded');
}

function toggleSidebar() {
    sidebarEl.classList.toggle('collapsed');
    mainWrapper.classList.toggle('expanded');
    localStorage.setItem('sidebarCollapsed', sidebarEl.classList.contains('collapsed'));
}

// Animate numbers on page load
document.addEventListener('DOMContentLoaded', () => {
    // Auto-dismiss flash
    setTimeout(() => {
        document.querySelectorAll('.flash-alert').forEach(el => {
            el.style.transition = 'all 0.4s';
            el.style.opacity = '0';
            el.style.transform = 'translateY(-20px)';
            setTimeout(() => el.remove(), 400);
        });
    }, 4500);

    // Add active class to nav based on current path
    const path = window.location.pathname;
    document.querySelectorAll('.nav-item').forEach(link => {
        if (link.getAttribute('href') && path.startsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
});

// Confirm before delete
document.querySelectorAll('[data-confirm]').forEach(btn => {
    btn.addEventListener('click', (e) => {
        if (!confirm(btn.dataset.confirm)) {
            e.preventDefault();
        }
    });
});
