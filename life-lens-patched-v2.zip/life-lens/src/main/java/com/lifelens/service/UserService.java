package com.lifelens.service;

import com.lifelens.model.User;
import com.lifelens.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(String username, String email, String fullName, String password) {
        if (userRepository.existsByUsername(username)) {
            throw new RuntimeException("Username already taken");
        }
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email already in use");
        }

        User user = User.builder()
                .username(username)
                .email(email)
                .fullName(fullName)
                .password(passwordEncoder.encode(password))
                .role("USER")
                .enabled(true)
                .build();

        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User updateLastLogin(String username) {
        User user = userRepository.findByUsername(username).orElseThrow();
        user.setLastLogin(LocalDateTime.now());
        return userRepository.save(user);
    }

    public User updateProfile(User user) {
        return userRepository.save(user);
    }

    public long countAll() {
        return userRepository.count();
    }
}
