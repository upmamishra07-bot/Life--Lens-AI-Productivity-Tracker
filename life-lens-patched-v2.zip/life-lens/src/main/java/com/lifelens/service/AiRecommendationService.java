package com.lifelens.service;

import com.lifelens.model.Habit;
import com.lifelens.model.Task;
import com.lifelens.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AiRecommendationService {

    private final HabitService habitService;
    private final TaskService taskService;

    public List<String> generateRecommendations(User user) {
        List<String> recommendations = new ArrayList<>();
        List<Habit> habits = habitService.getHabitsForUser(user);
        List<Task> tasks = taskService.getTasksForUser(user);

        long totalHabits = habits.size();
        long completedToday = habitService.countCompletedToday(user);
        long pendingTasks = taskService.countByStatus(user, "PENDING");
        long completedTasks = taskService.countByStatus(user, "COMPLETED");

        if (totalHabits == 0) {
            recommendations.add("🌱 Start your journey by creating your first habit. Small steps lead to big changes!");
        } else {
            double completionRate = totalHabits > 0 ? (double) completedToday / totalHabits * 100 : 0;
            if (completionRate >= 80) {
                recommendations.add("🔥 Outstanding! You've completed " + (int)completionRate + "% of your habits today. Keep this momentum going!");
            } else if (completionRate >= 50) {
                recommendations.add("💪 Good progress! You've completed " + (int)completionRate + "% of today's habits. Push for more!");
            } else {
                recommendations.add("📋 You've completed " + (int)completionRate + "% of today's habits. Try setting a reminder to stay on track.");
            }
        }

        // Streak analysis
        habits.stream()
                .filter(h -> h.getCurrentStreak() != null && h.getCurrentStreak() >= 7)
                .findFirst()
                .ifPresent(h -> recommendations.add("🏆 Amazing! Your '" + h.getName() + "' habit has a " + h.getCurrentStreak() + "-day streak! You're building a lasting routine."));

        habits.stream()
                .filter(h -> h.getCurrentStreak() != null && h.getCurrentStreak() == 0 && h.getCompletedCount() != null && h.getCompletedCount() > 5)
                .findFirst()
                .ifPresent(h -> recommendations.add("⚡ Your '" + h.getName() + "' habit streak reset. Today is a perfect day to restart. Consistency beats perfection!"));

        // Task analysis
        if (pendingTasks > 5) {
            recommendations.add("📌 You have " + pendingTasks + " pending tasks. Consider time-blocking 30 minutes to tackle the high-priority ones first.");
        }
        if (completedTasks > 0) {
            recommendations.add("✅ You've completed " + completedTasks + " tasks. Celebrate your wins — this builds productive momentum!");
        }

        // Category diversification
        boolean hasHealthHabit = habits.stream().anyMatch(h -> "Health".equalsIgnoreCase(h.getCategory()));
        boolean hasMindHabit = habits.stream().anyMatch(h -> "Mindfulness".equalsIgnoreCase(h.getCategory()) || "Mental".equalsIgnoreCase(h.getCategory()));
        if (!hasHealthHabit) {
            recommendations.add("🏃 Consider adding a health or fitness habit. Even 10 minutes of movement daily transforms your energy levels.");
        }
        if (!hasMindHabit) {
            recommendations.add("🧘 A mindfulness habit like meditation can improve focus and reduce stress. Start with just 5 minutes daily.");
        }

        // Morning routine tip
        recommendations.add("🌅 Research shows completing habits before 10 AM increases consistency by 68%. Try scheduling your core habits in the morning.");

        if (recommendations.size() > 5) {
            return recommendations.subList(0, 5);
        }

        return recommendations;
    }

    public int calculateProductivityScore(User user) {
        List<Habit> habits = habitService.getHabitsForUser(user);
        long completedToday = habitService.countCompletedToday(user);
        long completedTasks = taskService.countByStatus(user, "COMPLETED");
        long totalTasks = taskService.countAll(user);

        int score = 0;
        if (!habits.isEmpty()) {
            score += (int)((double) completedToday / habits.size() * 50);
        }
        if (totalTasks > 0) {
            score += (int)((double) completedTasks / totalTasks * 50);
        }

        int streakBonus = habits.stream()
                .mapToInt(h -> h.getCurrentStreak() != null ? Math.min(h.getCurrentStreak(), 10) : 0)
                .sum();
        score = Math.min(100, score + Math.min(streakBonus, 20));

        return score;
    }
}
