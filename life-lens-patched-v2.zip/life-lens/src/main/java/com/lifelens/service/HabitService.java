package com.lifelens.service;

import com.lifelens.model.Habit;
import com.lifelens.model.HabitLog;
import com.lifelens.model.User;
import com.lifelens.repository.HabitLogRepository;
import com.lifelens.repository.HabitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HabitService {

    private final HabitRepository habitRepository;
    private final HabitLogRepository habitLogRepository;

    public List<Habit> getHabitsForUser(User user) {
        return habitRepository.findByUserAndActiveTrue(user);
    }

    public Habit createHabit(Habit habit, User user) {
        habit.setUser(user);
        return habitRepository.save(habit);
    }

    public Optional<Habit> findById(Long id) {
        return habitRepository.findById(id);
    }

    public Habit save(Habit habit) {
        return habitRepository.save(habit);
    }

    @Transactional
    public HabitLog toggleHabitToday(Long habitId, User user) {
        Habit habit = habitRepository.findById(habitId).orElseThrow();
        LocalDate today = LocalDate.now();

        Optional<HabitLog> existingLog = habitLogRepository.findByHabitAndDate(habit, today);

        if (existingLog.isPresent()) {
            HabitLog log = existingLog.get();
            log.setCompleted(!log.isCompleted());
            habitLogRepository.save(log);
            updateStreak(habit);
            return log;
        } else {
            HabitLog log = HabitLog.builder()
                    .habit(habit)
                    .date(today)
                    .completed(true)
                    .build();
            habitLogRepository.save(log);
            habit.setLastCompleted(today);
            habit.setCompletedCount(habit.getCompletedCount() + 1);
            updateStreak(habit);
            habitRepository.save(habit);
            return log;
        }
    }

    private void updateStreak(Habit habit) {
        LocalDate today = LocalDate.now();
        int streak = 0;
        LocalDate checkDate = today;

        while (true) {
            Optional<HabitLog> log = habitLogRepository.findByHabitAndDate(habit, checkDate);
            if (log.isPresent() && log.get().isCompleted()) {
                streak++;
                checkDate = checkDate.minusDays(1);
            } else {
                break;
            }
        }

        habit.setCurrentStreak(streak);
        if (streak > habit.getLongestStreak()) {
            habit.setLongestStreak(streak);
        }
        habitRepository.save(habit);
    }

    public boolean isCompletedToday(Habit habit) {
        return habitLogRepository.findByHabitAndDate(habit, LocalDate.now())
                .map(HabitLog::isCompleted).orElse(false);
    }

    public void deleteHabit(Long id) {
        habitRepository.findById(id).ifPresent(h -> {
            h.setActive(false);
            habitRepository.save(h);
        });
    }

    public long countActiveHabits(User user) {
        return habitRepository.countByUserAndActiveTrue(user);
    }

    public List<HabitLog> getLogsForLastNDays(Habit habit, int days) {
        LocalDate end = LocalDate.now();
        LocalDate start = end.minusDays(days);
        return habitLogRepository.findByHabitAndDateBetween(habit, start, end);
    }

    public long countCompletedToday(User user) {
        List<HabitLog> todayLogs = habitLogRepository.findByUserIdAndDate(user.getId(), LocalDate.now());
        return todayLogs.stream().filter(HabitLog::isCompleted).count();
    }
}
