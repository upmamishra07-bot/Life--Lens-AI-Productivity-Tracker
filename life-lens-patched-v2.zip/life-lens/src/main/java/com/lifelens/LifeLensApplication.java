package com.lifelens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeLensApplication {
    public static void main(String[] args) {
        SpringApplication.run(LifeLensApplication.class, args);
    }
}
