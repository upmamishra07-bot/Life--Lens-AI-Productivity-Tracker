package com.lifelens.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "habits")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Habit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String description;
    private String category;
    private String icon;
    private String color;
    private String frequency; // DAILY, WEEKLY, MONTHLY
    private Integer targetDays;
    private Integer currentStreak;
    private Integer longestStreak;
    private Integer completedCount;
    private boolean active = true;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDate lastCompleted;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @OneToMany(mappedBy = "habit", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<HabitLog> logs;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (currentStreak == null) currentStreak = 0;
        if (longestStreak == null) longestStreak = 0;
        if (completedCount == null) completedCount = 0;
    }
}
