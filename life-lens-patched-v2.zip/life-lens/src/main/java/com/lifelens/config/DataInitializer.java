package com.lifelens.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * DataInitializer — demo data removed.
 * All data is created dynamically by real users via the UI.
 */
@Component
@Slf4j
public class DataInitializer implements CommandLineRunner {

    @Override
    public void run(String... args) {
        log.info("LifeLens started. No demo data seeded — all data is user-driven.");
    }
}
