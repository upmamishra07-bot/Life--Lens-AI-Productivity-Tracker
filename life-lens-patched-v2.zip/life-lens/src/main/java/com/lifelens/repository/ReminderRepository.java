package com.lifelens.repository;

import com.lifelens.model.Reminder;
import com.lifelens.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReminderRepository extends JpaRepository<Reminder, Long> {
    List<Reminder> findByUserAndActiveTrue(User user);
    List<Reminder> findByUser(User user);
}
