package com.lifelens.repository;

import com.lifelens.model.Task;
import com.lifelens.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByUser(User user);
    List<Task> findByUserAndStatus(User user, String status);
    List<Task> findByUserOrderByDueDateAsc(User user);
    long countByUserAndStatus(User user, String status);
}
