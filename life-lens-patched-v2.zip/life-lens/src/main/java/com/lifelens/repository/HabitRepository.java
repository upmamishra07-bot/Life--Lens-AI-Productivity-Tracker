package com.lifelens.repository;

import com.lifelens.model.Habit;
import com.lifelens.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface HabitRepository extends JpaRepository<Habit, Long> {
    List<Habit> findByUserAndActiveTrue(User user);
    List<Habit> findByUser(User user);
    long countByUserAndActiveTrue(User user);

    @Query("SELECT h FROM Habit h WHERE h.user = ?1 AND h.currentStreak > 0 ORDER BY h.currentStreak DESC")
    List<Habit> findTopStreaksByUser(User user);
}
