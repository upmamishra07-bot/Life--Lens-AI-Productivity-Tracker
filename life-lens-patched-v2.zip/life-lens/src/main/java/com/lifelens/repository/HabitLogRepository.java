package com.lifelens.repository;

import com.lifelens.model.Habit;
import com.lifelens.model.HabitLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HabitLogRepository extends JpaRepository<HabitLog, Long> {
    Optional<HabitLog> findByHabitAndDate(Habit habit, LocalDate date);
    List<HabitLog> findByHabitAndDateBetween(Habit habit, LocalDate start, LocalDate end);
    List<HabitLog> findByHabitAndCompleted(Habit habit, boolean completed);

    @Query("SELECT hl FROM HabitLog hl WHERE hl.habit.user.id = ?1 AND hl.date = ?2")
    List<HabitLog> findByUserIdAndDate(Long userId, LocalDate date);

    @Query("SELECT COUNT(hl) FROM HabitLog hl WHERE hl.habit.user.id = ?1 AND hl.completed = true AND hl.date BETWEEN ?2 AND ?3")
    long countCompletedByUserIdAndDateRange(Long userId, LocalDate start, LocalDate end);
}
