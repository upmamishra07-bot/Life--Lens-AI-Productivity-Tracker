package com.lifelens.controller;

import com.lifelens.model.Habit;
import com.lifelens.model.User;
import com.lifelens.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportsController {

    private final UserService userService;
    private final HabitService habitService;
    private final TaskService taskService;
    private final AiRecommendationService aiService;

    @GetMapping
    public String reports(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        List<Habit> habits = habitService.getHabitsForUser(user);

        int productivityScore = aiService.calculateProductivityScore(user);
        List<String> recommendations = aiService.generateRecommendations(user);

        long totalHabits   = habits.size();
        long completedToday = habitService.countCompletedToday(user);
        long totalTasks    = taskService.countAll(user);
        long completedTasks = taskService.countByStatus(user, "COMPLETED");
        long remainingTasks = totalTasks - completedTasks;

        int bestStreak = 0;
        int currentStreak = 0;
        for (Habit h : habits) {
            int ls = h.getLongestStreak()  != null ? h.getLongestStreak()  : 0;
            int cs = h.getCurrentStreak()  != null ? h.getCurrentStreak()  : 0;
            if (ls > bestStreak)    bestStreak    = ls;
            if (cs > currentStreak) currentStreak = cs;
        }

        // Progress bar widths per habit — avoids complex ternary inside th:style
        Map<Long, Integer> habitProgressMap = new HashMap<>();
        for (Habit h : habits) {
            int cs = h.getCurrentStreak()  != null ? h.getCurrentStreak()  : 0;
            int ls = h.getLongestStreak()  != null ? h.getLongestStreak()  : 0;
            habitProgressMap.put(h.getId(), ls > 0 ? Math.min(100, cs * 100 / ls) : 0);
        }

        model.addAttribute("user", user);
        model.addAttribute("habits", habits);
        model.addAttribute("totalHabits", totalHabits);
        model.addAttribute("completedToday", completedToday);
        model.addAttribute("totalTasks", totalTasks);
        model.addAttribute("completedTasks", completedTasks);
        model.addAttribute("remainingTasks", remainingTasks);
        model.addAttribute("productivityScore", productivityScore);
        model.addAttribute("recommendations", recommendations);
        model.addAttribute("bestStreak", bestStreak);
        model.addAttribute("currentStreak", currentStreak);
        model.addAttribute("habitProgressMap", habitProgressMap);

        return "reports/index";
    }
}
