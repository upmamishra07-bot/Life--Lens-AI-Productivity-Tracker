package com.lifelens.controller;

import com.lifelens.model.Task;
import com.lifelens.model.User;
import com.lifelens.service.TaskService;
import com.lifelens.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;
    private final UserService userService;

    @GetMapping
    public String tasks(@AuthenticationPrincipal UserDetails userDetails,
                        @RequestParam(required = false) String filter,
                        Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        List<Task> tasks;

        if (filter != null && !filter.isEmpty()) {
            tasks = taskService.getTasksByStatus(user, filter.toUpperCase());
        } else {
            tasks = taskService.getTasksForUser(user);
        }

        model.addAttribute("user", user);
        model.addAttribute("tasks", tasks);
        model.addAttribute("filter", filter);
        model.addAttribute("pendingCount", taskService.countByStatus(user, "PENDING"));
        model.addAttribute("inProgressCount", taskService.countByStatus(user, "IN_PROGRESS"));
        model.addAttribute("completedCount", taskService.countByStatus(user, "COMPLETED"));
        return "tasks/list";
    }

    @GetMapping("/new")
    public String newTaskForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        model.addAttribute("user", user);
        return "tasks/form";
    }

    @PostMapping("/new")
    public String createTask(@AuthenticationPrincipal UserDetails userDetails,
                              @RequestParam String title,
                              @RequestParam(required = false) String description,
                              @RequestParam String priority,
                              @RequestParam(required = false) String category,
                              @RequestParam(required = false) String dueDate,
                              RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        Task task = Task.builder()
                .title(title)
                .description(description)
                .priority(priority)
                .category(category)
                .dueDate(dueDate != null && !dueDate.isEmpty() ? LocalDate.parse(dueDate) : null)
                .status("PENDING")
                .build();
        taskService.createTask(task, user);
        redirectAttributes.addFlashAttribute("success", "Task created successfully!");
        return "redirect:/tasks";
    }

    @PostMapping("/{id}/status")
    public String updateStatus(@PathVariable Long id,
                                @RequestParam String status,
                                RedirectAttributes redirectAttributes) {
        taskService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("success", "Task status updated!");
        return "redirect:/tasks";
    }

    @PostMapping("/{id}/delete")
    public String deleteTask(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        taskService.deleteTask(id);
        redirectAttributes.addFlashAttribute("success", "Task deleted.");
        return "redirect:/tasks";
    }
}
