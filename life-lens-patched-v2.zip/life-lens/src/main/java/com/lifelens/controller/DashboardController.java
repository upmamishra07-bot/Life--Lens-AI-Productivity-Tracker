package com.lifelens.controller;

import com.lifelens.model.Habit;
import com.lifelens.model.User;
import com.lifelens.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserService userService;
    private final HabitService habitService;
    private final TaskService taskService;
    private final AiRecommendationService aiService;

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        userService.updateLastLogin(user.getUsername());

        List<Habit> habits = habitService.getHabitsForUser(user);
        long totalHabits = habits.size();
        long completedToday = habitService.countCompletedToday(user);
        long pendingTasks = taskService.countByStatus(user, "PENDING");
        long completedTasks = taskService.countByStatus(user, "COMPLETED");
        int productivityScore = aiService.calculateProductivityScore(user);
        List<String> recommendations = aiService.generateRecommendations(user);

        // Completion percentage
        double completionPct = totalHabits > 0 ? (double) completedToday / totalHabits * 100 : 0;

        model.addAttribute("user", user);
        model.addAttribute("habits", habits);
        model.addAttribute("totalHabits", totalHabits);
        model.addAttribute("completedToday", completedToday);
        model.addAttribute("pendingTasks", pendingTasks);
        model.addAttribute("completedTasks", completedTasks);
        model.addAttribute("productivityScore", productivityScore);
        model.addAttribute("recommendations", recommendations);
        model.addAttribute("completionPct", (int) completionPct);
        model.addAttribute("recentTasks", taskService.getTasksByStatus(user, "PENDING").stream().limit(5).toList());

        // Habit completion status map
        java.util.Map<Long, Boolean> completionMap = new java.util.HashMap<>();
        for (Habit h : habits) {
            completionMap.put(h.getId(), habitService.isCompletedToday(h));
        }
        model.addAttribute("completionMap", completionMap);

        return "dashboard/index";
    }
}
