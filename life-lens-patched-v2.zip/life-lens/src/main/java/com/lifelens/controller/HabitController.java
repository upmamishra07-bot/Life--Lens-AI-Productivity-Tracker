package com.lifelens.controller;

import com.lifelens.model.Habit;
import com.lifelens.model.User;
import com.lifelens.service.HabitService;
import com.lifelens.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Controller
@RequestMapping("/habits")
@RequiredArgsConstructor
public class HabitController {

    private final HabitService habitService;
    private final UserService userService;

    @GetMapping
    public String habits(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        List<Habit> habits = habitService.getHabitsForUser(user);

        Map<Long, Boolean> completionMap = new HashMap<>();
        long completedTodayCount = 0;
        int bestStreak = 0;

        for (Habit h : habits) {
            boolean done = habitService.isCompletedToday(h);
            completionMap.put(h.getId(), done);
            if (done) completedTodayCount++;
            int streak = h.getCurrentStreak() != null ? h.getCurrentStreak() : 0;
            if (streak > bestStreak) bestStreak = streak;
        }

        model.addAttribute("user", user);
        model.addAttribute("habits", habits);
        model.addAttribute("completionMap", completionMap);
        // Pre-computed values — avoids SpEL lambdas in template
        model.addAttribute("completedTodayCount", completedTodayCount);
        model.addAttribute("bestStreak", bestStreak);
        return "habits/list";
    }

    @GetMapping("/new")
    public String newHabitForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        model.addAttribute("user", user);
        model.addAttribute("habit", new Habit());
        return "habits/form";
    }

    @PostMapping("/new")
    public String createHabit(@AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam String name,
                               @RequestParam(required = false) String description,
                               @RequestParam String category,
                               @RequestParam String frequency,
                               @RequestParam String icon,
                               @RequestParam String color,
                               RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        Habit habit = Habit.builder()
                .name(name)
                .description(description)
                .category(category)
                .frequency(frequency)
                .icon(icon)
                .color(color)
                .active(true)
                .currentStreak(0)
                .longestStreak(0)
                .completedCount(0)
                .build();
        habitService.createHabit(habit, user);
        redirectAttributes.addFlashAttribute("success", "Habit created successfully!");
        return "redirect:/habits";
    }

    @PostMapping("/{id}/toggle")
    public String toggleHabit(@PathVariable Long id,
                               @AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam(required = false, defaultValue = "/habits") String redirectTo,
                               RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        habitService.toggleHabitToday(id, user);
        redirectAttributes.addFlashAttribute("success", "Habit updated!");
        return "redirect:" + redirectTo;
    }

    @PostMapping("/{id}/delete")
    public String deleteHabit(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        habitService.deleteHabit(id);
        redirectAttributes.addFlashAttribute("success", "Habit removed.");
        return "redirect:/habits";
    }

    @GetMapping("/{id}/edit")
    public String editHabitForm(@PathVariable Long id,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        Habit habit = habitService.findById(id).orElseThrow();
        model.addAttribute("user", user);
        model.addAttribute("habit", habit);
        return "habits/edit";
    }

    @PostMapping("/{id}/edit")
    public String updateHabit(@PathVariable Long id,
                               @RequestParam String name,
                               @RequestParam(required = false) String description,
                               @RequestParam String category,
                               @RequestParam String frequency,
                               @RequestParam String icon,
                               @RequestParam String color,
                               RedirectAttributes redirectAttributes) {
        Habit habit = habitService.findById(id).orElseThrow();
        habit.setName(name);
        habit.setDescription(description);
        habit.setCategory(category);
        habit.setFrequency(frequency);
        habit.setIcon(icon);
        habit.setColor(color);
        habitService.save(habit);
        redirectAttributes.addFlashAttribute("success", "Habit updated successfully!");
        return "redirect:/habits";
    }
}
